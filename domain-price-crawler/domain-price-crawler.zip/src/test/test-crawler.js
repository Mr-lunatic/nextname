#!/usr/bin/env node

require('dotenv').config();
const { testConnection } = require('../config/database');
const { testConnection: testAPI } = require('../services/nazhumi-api');
const { testCrawl } = require('../services/crawler');
const { getDataStats } = require('../services/database');
const { logger } = require('../utils/logger');

// 测试数据库连接
const testDatabase = async () => {
  console.log('\n🔍 Testing Database Connection...');
  console.log('─'.repeat(50));
  
  try {
    const connected = await testConnection();
    if (connected) {
      console.log('✅ Database connection: SUCCESS');
      
      // 获取数据统计
      const stats = await getDataStats();
      console.log(`📊 Total records: ${stats.total_records}`);
      console.log(`🏷️  Unique TLDs: ${stats.unique_tlds}`);
      console.log(`🏢 Unique registrars: ${stats.unique_registrars}`);
      console.log(`🆕 Fresh records: ${stats.fresh_records}`);
      
      return true;
    } else {
      console.log('❌ Database connection: FAILED');
      return false;
    }
  } catch (error) {
    console.log('❌ Database connection: ERROR');
    console.log(`   Error: ${error.message}`);
    return false;
  }
};

// 测试API连接
const testAPIConnection = async () => {
  console.log('\n🔍 Testing Nazhumi API Connection...');
  console.log('─'.repeat(50));
  
  try {
    const connected = await testAPI();
    if (connected) {
      console.log('✅ API connection: SUCCESS');
      return true;
    } else {
      console.log('❌ API connection: FAILED');
      return false;
    }
  } catch (error) {
    console.log('❌ API connection: ERROR');
    console.log(`   Error: ${error.message}`);
    return false;
  }
};

// 测试采集功能
const testCrawling = async () => {
  console.log('\n🔍 Testing Crawl Functionality...');
  console.log('─'.repeat(50));
  
  try {
    console.log('🚀 Starting test crawl (2 tasks)...');
    
    const results = await testCrawl();
    
    console.log('✅ Crawl test: SUCCESS');
    console.log(`📊 Results:`);
    console.log(`   - Total tasks: ${results.totalTasks}`);
    console.log(`   - Completed: ${results.completed}`);
    console.log(`   - Failed: ${results.failed}`);
    console.log(`   - Success rate: ${results.successRate}%`);
    console.log(`   - Duration: ${(results.duration / 1000).toFixed(1)}s`);
    
    if (results.errors.length > 0) {
      console.log('⚠️  Errors encountered:');
      results.errors.forEach(error => {
        console.log(`   - ${error.tld}/${error.registrar}: ${error.error}`);
      });
    }
    
    return results.completed > 0;
    
  } catch (error) {
    console.log('❌ Crawl test: FAILED');
    console.log(`   Error: ${error.message}`);
    return false;
  }
};

// 测试环境变量
const testEnvironment = () => {
  console.log('\n🔍 Testing Environment Configuration...');
  console.log('─'.repeat(50));
  
  const requiredVars = [
    'DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD'
  ];
  
  const optionalVars = [
    'DB_PORT', 'CRAWL_INTERVAL_MS', 'MAX_CONCURRENT_REQUESTS', 
    'DAILY_CRAWL_LIMIT', 'LOG_LEVEL'
  ];
  
  let allGood = true;
  
  // 检查必需变量
  console.log('📋 Required variables:');
  requiredVars.forEach(varName => {
    const value = process.env[varName];
    if (value) {
      console.log(`   ✅ ${varName}: ${varName.includes('PASSWORD') ? '***' : value}`);
    } else {
      console.log(`   ❌ ${varName}: MISSING`);
      allGood = false;
    }
  });
  
  // 检查可选变量
  console.log('\n📋 Optional variables:');
  optionalVars.forEach(varName => {
    const value = process.env[varName];
    if (value) {
      console.log(`   ✅ ${varName}: ${value}`);
    } else {
      console.log(`   ⚪ ${varName}: using default`);
    }
  });
  
  return allGood;
};

// 性能测试
const testPerformance = async () => {
  console.log('\n🔍 Testing Performance...');
  console.log('─'.repeat(50));
  
  try {
    const { fetchWithRetry } = require('../services/nazhumi-api');
    
    console.log('⏱️  Testing API response time...');
    
    const tests = [
      { registrar: 'cloudflare', tld: 'com' },
      { registrar: 'namecheap', tld: 'net' },
      { registrar: 'porkbun', tld: 'org' }
    ];
    
    const results = [];
    
    for (const test of tests) {
      const startTime = Date.now();
      try {
        await fetchWithRetry(test.registrar, test.tld);
        const responseTime = Date.now() - startTime;
        results.push({ ...test, responseTime, success: true });
        console.log(`   ✅ ${test.registrar}/${test.tld}: ${responseTime}ms`);
      } catch (error) {
        const responseTime = Date.now() - startTime;
        results.push({ ...test, responseTime, success: false, error: error.message });
        console.log(`   ❌ ${test.registrar}/${test.tld}: ${responseTime}ms (${error.message})`);
      }
      
      // 间隔2秒
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
    
    const avgResponseTime = results.reduce((sum, r) => sum + r.responseTime, 0) / results.length;
    const successRate = (results.filter(r => r.success).length / results.length * 100).toFixed(1);
    
    console.log(`\n📊 Performance Summary:`);
    console.log(`   - Average response time: ${avgResponseTime.toFixed(0)}ms`);
    console.log(`   - Success rate: ${successRate}%`);
    
    return avgResponseTime < 10000 && parseFloat(successRate) > 50; // 10秒内且成功率>50%
    
  } catch (error) {
    console.log('❌ Performance test: ERROR');
    console.log(`   Error: ${error.message}`);
    return false;
  }
};

// 主测试函数
const runAllTests = async () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║                    Crawler Test Suite                       ║
╚══════════════════════════════════════════════════════════════╝
  `);
  
  const results = {
    environment: false,
    database: false,
    api: false,
    crawling: false,
    performance: false
  };
  
  try {
    // 1. 测试环境配置
    results.environment = testEnvironment();
    
    // 2. 测试数据库连接
    if (results.environment) {
      results.database = await testDatabase();
    }
    
    // 3. 测试API连接
    results.api = await testAPIConnection();
    
    // 4. 测试采集功能
    if (results.database && results.api) {
      results.crawling = await testCrawling();
    }
    
    // 5. 性能测试
    if (results.api) {
      results.performance = await testPerformance();
    }
    
  } catch (error) {
    logger.error('Test suite error:', error.message);
  }
  
  // 显示测试结果
  console.log('\n📋 Test Results Summary:');
  console.log('─'.repeat(50));
  console.log(`🔧 Environment: ${results.environment ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`🗄️  Database: ${results.database ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`🌐 API: ${results.api ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`🔄 Crawling: ${results.crawling ? '✅ PASS' : '❌ FAIL'}`);
  console.log(`⚡ Performance: ${results.performance ? '✅ PASS' : '❌ FAIL'}`);
  
  const passCount = Object.values(results).filter(Boolean).length;
  const totalCount = Object.keys(results).length;
  
  console.log(`\n🎯 Overall: ${passCount}/${totalCount} tests passed`);
  
  if (passCount === totalCount) {
    console.log('🎉 All tests passed! System is ready to run.');
    return true;
  } else {
    console.log('⚠️  Some tests failed. Please check the configuration.');
    return false;
  }
};

// 如果直接运行此文件
if (require.main === module) {
  runAllTests().then(success => {
    process.exit(success ? 0 : 1);
  }).catch(error => {
    console.error('💥 Test suite crashed:', error);
    process.exit(1);
  });
}

module.exports = {
  runAllTests,
  testDatabase,
  testAPIConnection,
  testCrawling,
  testEnvironment,
  testPerformance
};
