const { v4: uuidv4 } = require('uuid');
const { fetchWithRetry } = require('./nazhumi-api');
const { 
  savePricingData, 
  updateTaskStatus, 
  logCrawlAttempt,
  getDataStats,
  getMissingCombinations,
  setConfig,
  getConfig
} = require('./database');
const { crawlLogger, logger } = require('../utils/logger');
const { CRAWL_CONFIG, PRIORITY_TLDS, PRIORITY_REGISTRARS } = require('../config/constants');

// 延迟函数
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// 生成采集计划
const generateCrawlPlan = async () => {
  try {
    logger.info('📋 Generating crawl plan...');
    
    // 获取当前数据统计
    const stats = await getDataStats();
    logger.info('📊 Current data stats:', stats);
    
    // 根据数据覆盖情况决定采集策略
    let tlds, registrars, maxTasks;
    
    if (stats.total_records < 500) {
      // 初始阶段：核心TLD + 主要注册商
      tlds = PRIORITY_TLDS.slice(0, 8); // 前8个核心TLD
      registrars = PRIORITY_REGISTRARS.slice(0, 10); // 前10个注册商
      maxTasks = 80;
      logger.info('🚀 Bootstrap mode: Core TLDs + Priority registrars');
    } else if (stats.total_records < 2000) {
      // 扩展阶段：更多TLD
      tlds = PRIORITY_TLDS.slice(0, 20); // 前20个TLD
      registrars = PRIORITY_REGISTRARS.slice(0, 15); // 前15个注册商
      maxTasks = 300;
      logger.info('📈 Expansion mode: Extended TLDs');
    } else {
      // 正常运营：完整覆盖
      tlds = PRIORITY_TLDS; // 所有优先TLD
      registrars = PRIORITY_REGISTRARS; // 所有优先注册商
      maxTasks = CRAWL_CONFIG.DAILY_LIMIT;
      logger.info('🎯 Normal mode: Full coverage');
    }
    
    // 获取缺失的组合
    const missingCombinations = await getMissingCombinations(tlds, registrars, 24);
    logger.info(`🕳️ Found ${missingCombinations.length} missing combinations`);
    
    // 限制任务数量
    const tasks = missingCombinations.slice(0, maxTasks);
    
    logger.info(`📋 Generated crawl plan: ${tasks.length} tasks`);
    return tasks;
    
  } catch (error) {
    logger.error('Failed to generate crawl plan:', error.message);
    throw error;
  }
};

// 执行单个采集任务
const executeCrawlTask = async (sessionId, task) => {
  const { tld, registrar } = task;
  const startTime = Date.now();
  
  try {
    // 获取价格数据
    const pricingData = await fetchWithRetry(registrar, tld);
    const responseTime = Date.now() - startTime;
    
    // 保存到数据库
    await savePricingData(pricingData);
    
    // 更新任务状态
    await updateTaskStatus(tld, registrar, 'completed');
    
    // 记录日志
    await logCrawlAttempt(sessionId, tld, registrar, 'success', responseTime);
    crawlLogger.success(sessionId, tld, registrar, responseTime);
    
    return {
      status: 'success',
      tld,
      registrar,
      responseTime,
      data: pricingData
    };
    
  } catch (error) {
    const responseTime = Date.now() - startTime;
    
    // 更新任务状态
    await updateTaskStatus(tld, registrar, 'failed', error.message);
    
    // 记录日志
    await logCrawlAttempt(sessionId, tld, registrar, 'failed', responseTime, error.message);
    crawlLogger.error(sessionId, tld, registrar, error, responseTime);
    
    return {
      status: 'failed',
      tld,
      registrar,
      responseTime,
      error: error.message
    };
  }
};

// 主采集函数
const executeCrawl = async (options = {}) => {
  const sessionId = uuidv4();
  const {
    maxTasks = null,
    interval = CRAWL_CONFIG.REQUEST_INTERVAL,
    onProgress = null
  } = options;
  
  try {
    // 记录采集开始
    await setConfig('crawl_session_id', sessionId);
    await setConfig('last_crawl_start', new Date().toISOString());
    
    // 生成采集计划
    const tasks = await generateCrawlPlan();
    
    if (tasks.length === 0) {
      logger.info('🎉 No crawling needed - all data is fresh!');
      return {
        sessionId,
        totalTasks: 0,
        completed: 0,
        failed: 0,
        skipped: 0,
        duration: 0
      };
    }
    
    // 限制任务数量
    const finalTasks = maxTasks ? tasks.slice(0, maxTasks) : tasks;
    
    crawlLogger.start(sessionId, finalTasks.length);
    
    const results = {
      sessionId,
      totalTasks: finalTasks.length,
      completed: 0,
      failed: 0,
      skipped: 0,
      startTime: Date.now(),
      errors: []
    };
    
    // 执行采集任务
    for (let i = 0; i < finalTasks.length; i++) {
      const task = finalTasks[i];
      
      try {
        // 带宽友好的间隔
        if (i > 0) {
          await sleep(interval);
        }
        
        // 执行任务
        const result = await executeCrawlTask(sessionId, task);
        
        if (result.status === 'success') {
          results.completed++;
        } else {
          results.failed++;
          results.errors.push({
            tld: task.tld,
            registrar: task.registrar,
            error: result.error
          });
        }
        
        // 进度回调
        if (onProgress) {
          onProgress(i + 1, finalTasks.length, task, result);
        }
        
        // 定期进度报告
        if ((i + 1) % 50 === 0) {
          crawlLogger.progress(sessionId, i + 1, finalTasks.length, task);
        }
        
        // 检查失败率
        const failureRate = results.failed / (results.completed + results.failed);
        if (failureRate > CRAWL_CONFIG.FAILURE_RATE_THRESHOLD && (results.completed + results.failed) > 20) {
          logger.warn(`⚠️ High failure rate detected: ${(failureRate * 100).toFixed(1)}%. Stopping crawl.`);
          break;
        }
        
      } catch (error) {
        logger.error(`❌ Unexpected error processing task ${task.tld}/${task.registrar}:`, error.message);
        results.failed++;
      }
    }
    
    // 计算总耗时
    results.duration = Date.now() - results.startTime;
    results.successRate = ((results.completed / results.totalTasks) * 100).toFixed(1);
    
    // 记录采集完成
    await setConfig('last_crawl_end', new Date().toISOString());
    await setConfig('last_crawl_stats', JSON.stringify({
      completed: results.completed,
      failed: results.failed,
      successRate: results.successRate,
      duration: results.duration
    }));
    
    crawlLogger.complete(sessionId, results);
    
    return results;
    
  } catch (error) {
    logger.error('❌ Crawl execution failed:', error.message);
    throw error;
  }
};

// 检查是否在采集时间窗口内
const isInCrawlWindow = () => {
  const now = new Date();
  const hour = now.getHours();
  
  return hour >= CRAWL_CONFIG.CRAWL_WINDOW.START_HOUR && 
         hour < CRAWL_CONFIG.CRAWL_WINDOW.END_HOUR;
};

// 获取采集状态
const getCrawlStatus = async () => {
  try {
    const stats = await getDataStats();
    const lastCrawlStart = await getConfig('last_crawl_start');
    const lastCrawlEnd = await getConfig('last_crawl_end');
    const lastCrawlStats = await getConfig('last_crawl_stats');
    const currentSessionId = await getConfig('crawl_session_id');
    
    return {
      dataStats: stats,
      lastCrawlStart,
      lastCrawlEnd,
      lastCrawlStats: lastCrawlStats ? JSON.parse(lastCrawlStats) : null,
      currentSessionId,
      isInCrawlWindow: isInCrawlWindow(),
      nextCrawlWindow: getNextCrawlWindow()
    };
  } catch (error) {
    logger.error('Failed to get crawl status:', error.message);
    throw error;
  }
};

// 获取下次采集窗口时间
const getNextCrawlWindow = () => {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(CRAWL_CONFIG.CRAWL_WINDOW.START_HOUR, 0, 0, 0);
  
  return tomorrow.toISOString();
};

// 测试采集功能
const testCrawl = async () => {
  logger.info('🧪 Testing crawl functionality...');
  
  try {
    const testTasks = [
      { tld: 'com', registrar: 'cloudflare' },
      { tld: 'net', registrar: 'namecheap' }
    ];
    
    const results = await executeCrawl({
      maxTasks: 2,
      interval: 3000
    });
    
    logger.info('✅ Crawl test completed:', results);
    return results;
    
  } catch (error) {
    logger.error('❌ Crawl test failed:', error.message);
    throw error;
  }
};

module.exports = {
  executeCrawl,
  generateCrawlPlan,
  executeCrawlTask,
  isInCrawlWindow,
  getCrawlStatus,
  testCrawl
};
